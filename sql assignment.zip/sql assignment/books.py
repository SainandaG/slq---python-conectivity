import mysql.connector

# Connect to the MySQL database
connection = mysql.connector.connect(
    host="localhost",
    user="root",  # replace with your MySQL username
    password="1234",  # replace with your MySQL password
    database="Library"
)

cursor = connection.cursor()

# Fetch all data from the Books table
cursor.execute("SELECT * FROM Books")
rows = cursor.fetchall()

# Display the data
for row in rows:
    print(row)

# Close the connection
cursor.close()
connection.close()
