import mysql.connector

# Connect to the MySQL database
connection = mysql.connector.connect(
    host="localhost",
    user="root",  # replace with your MySQL username
    password="1234",  # replace with your MySQL password
    database="Library"
)

cursor = connection.cursor()

# Delete a record from the Books table
delete_query = "DELETE FROM Books WHERE bookID = %s"
book_id_to_delete = 2
cursor.execute(delete_query, (book_id_to_delete,))
connection.commit()

# Fetch the remaining data
cursor.execute("SELECT * FROM Books")
remaining_rows = cursor.fetchall()

# Display the remaining data
for row in remaining_rows:
    print(row)

# Close the connection
cursor.close()
connection.close()
