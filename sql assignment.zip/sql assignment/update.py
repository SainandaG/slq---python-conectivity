import mysql.connector

# Connect to the MySQL database
connection = mysql.connector.connect(
    host="localhost",
    user="root",  # replace with your MySQL username
    password="1234",  # replace with your MySQL password
    database="Library"
)

cursor = connection.cursor()

# Update a record in the Books table
update_query = "UPDATE Books SET price = %s WHERE bookID = %s"
new_price = 12.99
book_id = 1
cursor.execute(update_query, (new_price, book_id))
connection.commit()

# Fetch the updated data
cursor.execute("SELECT * FROM Books WHERE bookID = %s", (book_id,))
updated_row = cursor.fetchone()
print("Updated Record:", updated_row)

# Close the connection
cursor.close()
connection.close()
